import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { library } from "@fortawesome/fontawesome-svg-core";
import { faTemperatureHalf, faSun, faTemperatureLow, faTemperatureHigh, faCloud, faDroplet, faWind } from '@fortawesome/free-solid-svg-icons';

library.add( faTemperatureHalf, faSun, faTemperatureLow, faTemperatureHigh, faCloud, faDroplet, faWind);

export const Card = ({icone, data, desc, temp_atual, sens_term, temp_min, temp_max, nuvens, umi, vel_vento}) => {

    return (
        <div className='Card'>
            <img className='card__img' src={icone} alt=''/>
            <div className='card__body'>
                <h2 className='card__date'>{data}</h2>
                <h3 className='card__description'>{desc}</h3>
                <p className='card__temp'><FontAwesomeIcon icon="temperature-half" data-hover="Temperatura Atual" /> {temp_atual}</p>
                <p className='card__ther_sens'><FontAwesomeIcon icon="sun" /> {sens_term}</p>
                <p className='card__temp_min'><FontAwesomeIcon icon="temperature-low" /> {temp_min}</p>
                <p className='card__temp_max'><FontAwesomeIcon icon="temperature-high" /> {temp_max}</p>
                <p className='card__clouds'><FontAwesomeIcon icon="cloud" /> {nuvens}</p>
                <p className='card__hum'><FontAwesomeIcon icon="droplet" /> {umi}</p>
                <p className='card__wind'><FontAwesomeIcon icon="wind" /> {vel_vento}</p>
            </div>
        </div>
    )

}